package com.cts.donation.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cts.donation.constant.DonationType;
import com.cts.donation.controller.DonationRequestController;
import com.cts.donation.entity.DonationRequest;
import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.BadRequestException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.UserRepository;
import com.cts.donation.services.impl.DonationRequestServiceImpl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DonationRequestControllerTest {

    @InjectMocks
    DonationRequestController donationRequestController;

    @Mock
    DonationRequestServiceImpl DonationRequestService;

    @Mock
    UserRepository userRepository;

    @Test
    public void testAddDonationRequest() throws AlreadyExistException, BadRequestException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        User user = new User();
        user.setId(1);

        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setUser(user);

        when(userRepository.findById(anyInt())).thenReturn(Optional.of(user));
        when(DonationRequestService.addDonationRequest(any(DonationRequest.class))).thenReturn(donationRequest);

        ResponseEntity<DonationRequest> responseEntity = donationRequestController.addDonationRequest(donationRequest);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.CREATED);
    }


    @Test
    public void testFindDonationRequestById() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.findDonationRequestById(anyInt())).thenReturn(new DonationRequest());

        ResponseEntity<DonationRequest> responseEntity = donationRequestController.findDonationRequestById(1, false);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationRequestByCity() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.findDonationRequestByCity(anyString(), any(Pageable.class))).thenReturn(Collections.singletonList(new DonationRequest()));

        ResponseEntity<List<DonationRequest>> responseEntity = donationRequestController.findDonationRequestByCity(0, "New York");

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationRequestByUserId() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.findDonationRequestByUserId(anyInt(), any(Pageable.class))).thenReturn(Collections.singletonList(new DonationRequest()));

        ResponseEntity<List<DonationRequest>> responseEntity = donationRequestController.findDonationRequestByUserId(1, 0);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testUpdateDonationRequestById() throws NotFoundException, BadRequestException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.updateDonationRequestById(anyInt(), any(DonationRequest.class))).thenReturn(new DonationRequest());

        ResponseEntity<DonationRequest> responseEntity = donationRequestController.updateDonationRequestById(1, new DonationRequest());

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testDeleteDonationRequestById() throws NotFoundException, BadRequestException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.deleteDonationRequestById(anyInt())).thenReturn(true);

        ResponseEntity<String> responseEntity = donationRequestController.deleteDonationRequestById(1);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }
    
    @Test
    public void testFindDonationRequestByCityAndDate() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.findDonationRequestByCityAndDate(anyString(), any(Date.class), any(Pageable.class))).thenReturn(Collections.singletonList(new DonationRequest()));

        ResponseEntity<List<DonationRequest>> responseEntity = donationRequestController.findDonationRequestByCityAndDate("New York", Date.valueOf(LocalDate.now()), 0);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationRequestByCityAndDateAndDonationType() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(DonationRequestService.findDonationRequestByCityAndDateAndDonationType(anyString(), any(Date.class), any(DonationType.class), any(Pageable.class))).thenReturn(Collections.singletonList(new DonationRequest()));

        ResponseEntity<List<DonationRequest>> responseEntity = donationRequestController.findDonationRequestByCityAndDateAndDonationType("New York", Date.valueOf(LocalDate.now()), DonationType.FURNITURE, 0);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }
}


