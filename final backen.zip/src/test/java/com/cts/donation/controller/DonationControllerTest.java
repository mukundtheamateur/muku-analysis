package com.cts.donation.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.cts.donation.constant.DonationType;
import com.cts.donation.controller.DonationController;
import com.cts.donation.entity.Donation;
import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.BadRequestException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.UserRepository;
import com.cts.donation.services.impl.DonationServiceImpl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DonationControllerTest {

    @InjectMocks
    DonationController donationController;

    @Mock
    DonationServiceImpl donationService;

    @Mock
    UserRepository userRepository;

    @Test
    public void testAddDonation() throws AlreadyExistException, BadRequestException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        User user = new User();
        user.setId(1);

        Donation donation = new Donation();
        donation.setUser(user);

        when(userRepository.findById(anyInt())).thenReturn(Optional.of(user));
        when(donationService.addDonation(any(Donation.class))).thenReturn(donation);

        ResponseEntity<Donation> responseEntity = donationController.addDonation(donation);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.CREATED);
    }


    @Test
    public void testFindDonationById() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(donationService.findDonationById(anyInt())).thenReturn(new Donation());

        ResponseEntity<Donation> responseEntity = donationController.findDonationById(1, false);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationByCity() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(donationService.findDonationByCity(anyString(), any(Pageable.class))).thenReturn(Collections.singletonList(new Donation()));

        ResponseEntity<List<Donation>> responseEntity = donationController.findDonationByCity(0, "New York", false);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationByCityAndDate() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(donationService.findDonationByCityAndDate(anyString(), any(Date.class), any(Pageable.class))).thenReturn(Collections.singletonList(new Donation()));

        ResponseEntity<List<Donation>> responseEntity = donationController.findDonationByCityAndDate("New York", Date.valueOf(LocalDate.now()), 0, false);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }

    @Test
    public void testFindDonationByCityAndDateAndDonationType() throws NotFoundException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(donationService.findDonationByCityAndDateAndDonationType(anyString(), any(Date.class), any(DonationType.class), any(Pageable.class))).thenReturn(Collections.singletonList(new Donation()));

        ResponseEntity<List<Donation>> responseEntity = donationController.findDonationByCityAndDateAndDonationType("New York", Date.valueOf(LocalDate.now()), DonationType.FURNITURE, 0, false);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }



    @Test
    public void testDeleteDonationById() throws NotFoundException, BadRequestException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

        when(donationService.deleteDonationById(anyInt())).thenReturn(true);

        ResponseEntity<String> responseEntity = donationController.deleteDonationById(1);

        assertEquals(responseEntity.getStatusCode(), HttpStatus.OK);
    }
}

