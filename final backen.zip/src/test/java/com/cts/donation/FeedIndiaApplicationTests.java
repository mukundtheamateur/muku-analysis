package com.cts.donation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedIndiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
