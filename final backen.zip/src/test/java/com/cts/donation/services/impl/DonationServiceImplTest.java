package com.cts.donation.services.impl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.Donation;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.DonationRepository;
import com.cts.donation.services.impl.DonationServiceImpl;

import java.util.Collections;
import java.sql.Date;

import java.util.List;
import java.util.Optional;


import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
public class DonationServiceImplTest {

    @InjectMocks
    private DonationServiceImpl DonationService;

    @Mock
    private DonationRepository donationRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddDonation() throws AlreadyExistException {
        Donation donation = new Donation();
        donation.setDonationName("Pizza");

        when(donationRepository.save(any(Donation.class))).thenReturn(donation);

        Donation result = DonationService.addDonation(donation);

        assertNotNull(result);
        assertEquals("Pizza", result.getDonationName());
    }

    @Test
    public void testFindDonationById() throws NotFoundException {
        Donation donation = new Donation();
        donation.setId(1);

        when(donationRepository.findById(anyInt())).thenReturn(Optional.of(donation));

        Donation result = DonationService.findDonationById(1);

        assertNotNull(result);
        assertEquals(1, result.getId());
    }

    @Test
    public void testFindDonationByCity() {
        Donation donation = new Donation();
        donation.setCity("New York");

        when(donationRepository.findByCity(anyString(), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donation)));

        List<Donation> result = DonationService.findDonationByCity("New York", PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
    }

    @Test
    public void testFindDonationByCityAndDate() {
        Donation donation = new Donation();
        donation.setCity("New York");
        donation.setPickupDate(new Date(0));

        when(donationRepository.findByCityDate(anyString(), any(Date.class), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donation)));

        List<Donation> result = DonationService.findDonationByCityAndDate("New York", new Date(0), PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
    }

    @Test
    public void testFindDonationByCityAndDateAndDonationType() {
        Donation donation = new Donation();
        donation.setCity("New York");
        donation.setPickupDate(new Date(0));
        donation.setDonationType(DonationType.FURNITURE);

        when(donationRepository.findByCityDateType(anyString(), any(Date.class), any(DonationType.class), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donation)));

        List<Donation> result = DonationService.findDonationByCityAndDateAndDonationType("New York", new Date(0), DonationType.FURNITURE, PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
        assertEquals(DonationType.FURNITURE, result.get(0).getDonationType());
    }

    @Test
    public void testUpdateDonationById() throws NotFoundException {
        Donation oldDonation = new Donation();
        oldDonation.setId(1);
        oldDonation.setDonationName("Old Name");
        oldDonation.setAmount(10);

        Donation newDonation = new Donation();
        newDonation.setDonationName("New Name");
        newDonation.setAmount(20); // Set the amount on newDonation, not oldDonation

        when(donationRepository.findById(anyInt())).thenReturn(Optional.of(oldDonation));
        when(donationRepository.save(any(Donation.class))).thenReturn(newDonation);

        Donation result = DonationService.updateDonationById(1, newDonation);

        assertNotNull(result);
        assertEquals("New Name", result.getDonationName());
    }


    @Test
    public void testDeleteDonationById() throws NotFoundException {
        Donation donation = new Donation();
        donation.setId(1);

        when(donationRepository.findById(anyInt())).thenReturn(Optional.of(donation));

        boolean result = DonationService.deleteDonationById(1);

        assertTrue(result);
    }
}

