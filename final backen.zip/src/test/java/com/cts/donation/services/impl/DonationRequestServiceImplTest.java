package com.cts.donation.services.impl;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.DonationRequest;
import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.DonationRequestRepository;
import com.cts.donation.services.impl.DonationRequestServiceImpl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class DonationRequestServiceImplTest {

    @InjectMocks
    private DonationRequestServiceImpl DonationRequestService;

    @Mock
    private DonationRequestRepository donationRequestRepository;

    @Test
    public void testAddDonationRequest() throws AlreadyExistException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setDonationType(DonationType.FURNITURE);

        when(donationRequestRepository.save(any(DonationRequest.class))).thenReturn(donationRequest);

        DonationRequest result = DonationRequestService.addDonationRequest(donationRequest);

        assertNotNull(result);
        assertEquals(DonationType.FURNITURE, result.getDonationType());
    }

    @Test
    public void testFindDonationRequestById() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setId(1);

        when(donationRequestRepository.findById(anyInt())).thenReturn(Optional.of(donationRequest));

        DonationRequest result = DonationRequestService.findDonationRequestById(1);

        assertNotNull(result);
        assertEquals(1, result.getId());
    }

    @Test
    public void testFindDonationRequestByCity() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setCity("New York");

        when(donationRequestRepository.findByCity(anyString(), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donationRequest)));

        List<DonationRequest> result = DonationRequestService.findDonationRequestByCity("New York", PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
    }

    @Test
    public void testFindDonationRequestByCityAndDate() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setCity("New York");
        donationRequest.setPickupDate(Date.valueOf(LocalDate.now()));

        when(donationRequestRepository.findByCityDate(anyString(), any(Date.class), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donationRequest)));

        List<DonationRequest> result = DonationRequestService.findDonationRequestByCityAndDate("New York", Date.valueOf(LocalDate.now()), PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
    }

    @Test
    public void testFindDonationRequestByCityAndDateAndDonationType() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setCity("New York");
        donationRequest.setPickupDate(Date.valueOf(LocalDate.now()));
        donationRequest.setDonationType(DonationType.FURNITURE);

        when(donationRequestRepository.findByCityDateType(anyString(), any(Date.class), any(DonationType.class), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donationRequest)));

        List<DonationRequest> result = DonationRequestService.findDonationRequestByCityAndDateAndDonationType("New York", Date.valueOf(LocalDate.now()), DonationType.FURNITURE, PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals("New York", result.get(0).getCity());
        assertEquals(DonationType.FURNITURE, result.get(0).getDonationType());
    }

    @Test
    public void testUpdateDonationRequestById() throws NotFoundException {
        DonationRequest oldDonationRequest = new DonationRequest();
        oldDonationRequest.setId(1);
        oldDonationRequest.setDonationType(DonationType.ANY);

        DonationRequest newDonationRequest = new DonationRequest();
        newDonationRequest.setDonationType(DonationType.FURNITURE);
        newDonationRequest.setAmount(10); // Set an amount for newDonationRequest

        when(donationRequestRepository.findById(anyInt())).thenReturn(Optional.of(oldDonationRequest));
        when(donationRequestRepository.save(any(DonationRequest.class))).thenReturn(newDonationRequest);

        DonationRequest result = DonationRequestService.updateDonationRequestById(1, newDonationRequest);

        assertNotNull(result);
        assertEquals(DonationType.FURNITURE, result.getDonationType());
    }

    @Test
    public void testDeleteDonationRequestById() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        donationRequest.setId(1);

        when(donationRequestRepository.findById(anyInt())).thenReturn(Optional.of(donationRequest));

        boolean result = DonationRequestService.deleteDonationRequestById(1);

        assertTrue(result);
    }

    @Test
    public void testFindDonationRequestByUserId() throws NotFoundException {
        DonationRequest donationRequest = new DonationRequest();
        User user =new User();
        user.setId(1);
        donationRequest.setUser(user);

        when(donationRequestRepository.findByUserId(anyInt(), any(Pageable.class))).thenReturn(new PageImpl<>(Collections.singletonList(donationRequest)));

        List<DonationRequest> result = DonationRequestService.findDonationRequestByUserId(1, PageRequest.of(0, 5));

        assertFalse(result.isEmpty());
        assertEquals(1, result.get(0).getUser().getId());
    }
}

