package com.cts.donation.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.donation.entity.User;
import com.cts.donation.entity.UserDto;
import com.cts.donation.exception.BadRequestException;
import com.cts.donation.repository.UserRepository;
import com.cts.donation.security.AuthenticationRequest;
import com.cts.donation.security.jwt.JwtUtil;
import com.cts.donation.services.impl.UserServiceImpl;

import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
 

 

@RestController
@RequestMapping("/v1/api")
public class LoginLogoutController {

   @Autowired
   private AuthenticationManager authenticationManager;
   
   @Autowired
   private UserRepository userRepository;

   @Autowired
   private UserServiceImpl userService;

   @Autowired
   private JwtUtil jwtUtil;

   @Autowired
   private UserDetailsService userDetailsService;

   @PostMapping("/login")
   public ResponseEntity<?> login(@RequestBody AuthenticationRequest authenticationRequest, HttpServletResponse res) throws BadRequestException {
       try {
           authenticationManager.authenticate(
                   new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
           );
       } catch (Exception e) {
           throw new BadRequestException("Inavlid username or password");
       }


       final UserDetails userDetails = userDetailsService.loadUserByUsername(authenticationRequest.getUsername());
       final String jwt = jwtUtil.generateToken(userDetails);
       final String refreshJwtToken = jwtUtil.generateRefreshToken(userDetails);


       User user = userRepository.findByEmail(authenticationRequest.getUsername());

       user = userService.updateUserByRefreshToken(refreshJwtToken, user);


       user = userRepository.save(user);
       // Create a new cookie
       Cookie jwtCookie = new Cookie("jwt", jwt);
       jwtCookie.setHttpOnly(true);
       jwtCookie.setMaxAge(3600);
       jwtCookie.setPath("/");
       jwtCookie.setSecure(true);

       // Create a new cookie
       Cookie refreshJwtCookie = new Cookie("refreshJwtToken", refreshJwtToken);
       refreshJwtCookie.setHttpOnly(true);
       refreshJwtCookie.setMaxAge(86400);
       refreshJwtCookie.setPath("/");
       refreshJwtCookie.setSecure(true);
       
       // Add the cookie to the response
       res.addCookie(jwtCookie);
       res.addCookie(refreshJwtCookie);
       
       UserDto userDto = new UserDto();
       userDto.convertToDto(user);
       return ResponseEntity.ok(userDto);
   }
   
   @PostMapping("/logout")
   public ResponseEntity<?> logout(HttpServletRequest request, HttpServletResponse response) {
       String jwt = null;
       String refreshToken = null;
       
       Cookie[] cookies = request.getCookies();
       if (cookies != null) {
           for (Cookie cookie : cookies) {
               if (cookie.getName().equals("jwt")) {
                   jwt = cookie.getValue();
               } else if (cookie.getName().equals("refreshJwtToken")) {
                   refreshToken = cookie.getValue();
               }
           }
       }

       if (jwt != null && jwtUtil.isTokenExpired(jwt)) {
           // If JWT is expired, try to refresh the token using the refresh token
           if (refreshToken != null && !jwtUtil.isTokenExpired(refreshToken)) {
               // Here you could generate a new JWT if needed
               UserDetails userDetails = userDetailsService.loadUserByUsername(jwtUtil.extractUsername(refreshToken));
               String newJwt = jwtUtil.generateToken(userDetails);

               Cookie newJwtCookie = new Cookie("jwt", newJwt);
               newJwtCookie.setHttpOnly(true);
               newJwtCookie.setMaxAge(3600);  // Adjust expiry as needed
               newJwtCookie.setPath("/");
               newJwtCookie.setSecure(true);

               response.addCookie(newJwtCookie);
           } else {
               // If both tokens are expired, handle accordingly (e.g., force re-login)
               return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Session expired. Please log in again.");
           }
       }

       // Continue with logout (invalidate session, remove cookies)
       request.getSession().invalidate();

       Cookie jwtCookie = new Cookie("jwt", null);
       jwtCookie.setHttpOnly(true);
       jwtCookie.setMaxAge(0);
       jwtCookie.setPath("/");
       jwtCookie.setSecure(true);

       Cookie refreshJwtCookie = new Cookie("refreshJwtToken", null);
       refreshJwtCookie.setHttpOnly(true);
       refreshJwtCookie.setMaxAge(0);
       refreshJwtCookie.setPath("/");
       refreshJwtCookie.setSecure(true);

       response.addCookie(jwtCookie);
       response.addCookie(refreshJwtCookie);

       Map<String, String> resBody = new HashMap<>();
       resBody.put("message", "Logout successful");

       return ResponseEntity.ok(resBody);
   }

   
   
   @GetMapping("/load/user")
   public ResponseEntity<?> loadUser(HttpServletRequest request) throws BadRequestException {
       String username = null;
       String jwt = null;
       String refreshToken = null;

       Cookie[] cookies = request.getCookies();
       if (cookies != null) {
           for (Cookie cookie : cookies) {
               if (cookie.getName().equals("jwt")) {
                   jwt = cookie.getValue();
                   try {
                       username = jwtUtil.extractUsername(jwt);
                   } catch (ExpiredJwtException e) {
                       return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("JWT token is expired");
                   } catch (Exception e) {
                       throw new BadRequestException("Invalid JWT token");
                   }
                   break;
               }
           }

           if (jwt == null) {
               for (Cookie cookie : cookies) {
                   if (cookie.getName().equals("refreshJwtToken")) {
                       refreshToken = cookie.getValue();
                       try {
                           username = jwtUtil.extractUsername(refreshToken);
                       } catch (ExpiredJwtException e) {
                           return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Refresh token is expired");
                       } catch (Exception e) {
                           throw new BadRequestException("Invalid refresh token");
                       }
                       break;
                   }
               }
           }
       } else {
           throw new BadRequestException("Login to use all features");
       }

       if (username != null) {
           User user = userRepository.findByEmail(username);
           return ResponseEntity.ok(user);
       }

       return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("JWT token is invalid");
   }

}