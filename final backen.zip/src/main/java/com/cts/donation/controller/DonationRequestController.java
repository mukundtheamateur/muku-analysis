package com.cts.donation.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.DonationRequest;
import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.BadRequestException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.UserRepository;
import com.cts.donation.services.impl.DonationRequestServiceImpl;

@RestController
@RequestMapping("/v1/api/donationRequest")
public class DonationRequestController {

    @Autowired
    private DonationRequestServiceImpl DonationRequestService;
    
    @Autowired
    private UserRepository userRepository;
    
    private int pageSize=15;

    @PostMapping("/create")
    public ResponseEntity<DonationRequest> addDonationRequest(@RequestBody DonationRequest donationRequest) throws AlreadyExistException, BadRequestException {
        
    	User user = userRepository.findById(donationRequest.getUser().getId()).get();
    	donationRequest.setUser(user);
    	donationRequest.setFullfilled(false);
    	donationRequest.setRequestedAmount(donationRequest.getAmount());
    	DonationRequest newDonationRequest = DonationRequestService.addDonationRequest(donationRequest);
        if (newDonationRequest == null) {
            throw new BadRequestException("DonationRequest creation failed");
        }
        return new ResponseEntity<>(newDonationRequest, HttpStatus.CREATED);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<DonationRequest> findDonationRequestById(@PathVariable int id, @RequestParam(required = false) boolean includeUser) throws NotFoundException {
        DonationRequest donationRequest = DonationRequestService.findDonationRequestById(id);
        if (donationRequest == null) {
            throw new NotFoundException("No DonationRequest found with the provided ID");
        }
        if (!includeUser) {
            donationRequest.setUser(null);
        }
        return new ResponseEntity<>(donationRequest, HttpStatus.OK);
    }

    @GetMapping("/city/{city}/page/{page}")
    public ResponseEntity<List<DonationRequest>> findDonationRequestByCity(@PathVariable int page,@PathVariable String city) throws NotFoundException {		
    	Pageable pageable = PageRequest.of(page, this.pageSize);
        List<DonationRequest> donationRequests = DonationRequestService.findDonationRequestByCity(city,pageable);
        if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found in the provided city");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }
    
    @GetMapping("/city/{city}/date/{date}/page/{page}")
    public ResponseEntity<List<DonationRequest>> findDonationRequestByCityAndDate(@PathVariable String city, @PathVariable Date date, @PathVariable int page) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize,Sort.by("pickupDate"));
        List<DonationRequest> donationRequests = DonationRequestService.findDonationRequestByCityAndDate(city, date, pageable);
        if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found for the provided city and date");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }
    
    @GetMapping("/page/{page}")
    public ResponseEntity<List<DonationRequest>> findAllDonationRequest(@PathVariable int page) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize,Sort.by("pickupDate"));
        List<DonationRequest> donationRequests = DonationRequestService.findAllDonationRequest(pageable);
        if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }
    
    
    @GetMapping("/city/{city}/type/{type}/page/{page}")
    public ResponseEntity<List<DonationRequest>> findDonationRequestByCityAndDonationType(@PathVariable String city, @PathVariable DonationType type, @PathVariable int page) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize,Sort.by("pickupDate"));
        List<DonationRequest> donationRequests = DonationRequestService.findDonationRequestByCityAndDonationType(city, type, pageable);
        if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found for the provided city, and Donation type");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }

    @GetMapping("/city/{city}/date/{date}/type/{type}/page/{page}")
    public ResponseEntity<List<DonationRequest>> findDonationRequestByCityAndDateAndDonationType(@PathVariable String city, @PathVariable Date date, @PathVariable DonationType type, @PathVariable int page) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize,Sort.by("pickupDate"));
        List<DonationRequest> donationRequests = DonationRequestService.findDonationRequestByCityAndDateAndDonationType(city, date, type, pageable);
        if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found for the provided city, date, and donation type");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }


    @PutMapping("/update/{id}")
    public ResponseEntity<DonationRequest> updateDonationRequestById(@PathVariable int id, @RequestBody DonationRequest donationRequest) throws NotFoundException, BadRequestException {
        DonationRequest updatedDonationRequest = DonationRequestService.updateDonationRequestById(id, donationRequest);
        if (updatedDonationRequest == null) {
            throw new BadRequestException("Failed to update the DonationRequest");
        }
        updatedDonationRequest.setUser(null);
        return new ResponseEntity<>(updatedDonationRequest, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteDonationRequestById(@PathVariable int id) throws NotFoundException, BadRequestException {
        boolean isRemoved = DonationRequestService.deleteDonationRequestById(id);
        if (!isRemoved) {
            throw new BadRequestException("Failed to delete the DonationRequest");
        }
        return new ResponseEntity<>("DonationRequest deleted successfully", HttpStatus.OK);
    }
    
    @GetMapping("/find/user/{userId}/page/{page}")
    public ResponseEntity<List<DonationRequest>> findDonationRequestByUserId(@PathVariable int userId, @PathVariable int page) throws NotFoundException{
    	
    	Pageable pageable = PageRequest.of(page, this.pageSize, Sort.by("pickupDate"));
    	List<DonationRequest> donationRequests = DonationRequestService.findDonationRequestByUserId(userId, pageable);
    	if (donationRequests.isEmpty()) {
            throw new NotFoundException("No DonationRequests found for the provided userId");
        }
        donationRequests.forEach(request -> {
            request.setUser(null);
        });
        return new ResponseEntity<>(donationRequests, HttpStatus.OK);
    }
}

