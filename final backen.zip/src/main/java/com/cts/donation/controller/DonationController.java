package com.cts.donation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.Donation;
import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.BadRequestException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.UserRepository;
import com.cts.donation.services.impl.DonationServiceImpl;

import java.sql.Date;
import java.util.List;


@RestController
@RequestMapping("/v1/api/donation")
public class DonationController {
	
	private int pageSize=15;

    @Autowired
    private DonationServiceImpl DonationService;
    
    @Autowired
    private UserRepository userRepository;

    @PostMapping("/create")
    public ResponseEntity<Donation> addDonation(@RequestBody Donation donation) throws AlreadyExistException, BadRequestException {

    	User user = userRepository.findById(donation.getUser().getId()).get();
    	if(user==null) {
    		throw new BadRequestException("bas req");
    	}
    	donation.setUser(user);
    	donation.setPostedAmount(donation.getAmount());
    	Donation newDonation = DonationService.addDonation(donation);
        if (newDonation == null) {
            throw new BadRequestException("Donation creation failed");
        }
        return new ResponseEntity<>(newDonation, HttpStatus.CREATED);
    }

    @GetMapping("id/{id}")
    public ResponseEntity<Donation> findDonationById(@PathVariable int id, @RequestParam(required = false) boolean includeUser) throws NotFoundException {
        Donation donation = DonationService.findDonationById(id);
        if (donation == null) {
            throw new NotFoundException("No Donation found with the provided ID");
        }
        if (!includeUser) {
            donation.setUser(null);  // Set the user to null if includeUser is false
        }
        return new ResponseEntity<>(donation, HttpStatus.OK);
    }

    @GetMapping("/city/{city}/page/{page}")
    public ResponseEntity<List<Donation>> findDonationByCity(@PathVariable int page,@PathVariable String city,@RequestParam(required=false) boolean includeUser) throws NotFoundException {
    	
    	Pageable pageable = PageRequest.of(page,this.pageSize,Sort.by("pickupDate"));
    	List<Donation> donations = DonationService.findDonationByCity(city, pageable);
    	if (donations.isEmpty()) {
            throw new NotFoundException("No Donation found for the provided city");
        }
    	if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }
    
    @GetMapping("/city/{city}/date/{date}/page/{page}")
    public ResponseEntity<List<Donation>> findDonationByCityAndDate(@PathVariable String city, @PathVariable Date date, @PathVariable int page,@RequestParam(required=false) boolean includeUser) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize);
        List<Donation> donations = DonationService.findDonationByCityAndDate(city, date, pageable);
        if (donations.isEmpty()) {
            throw new NotFoundException("No Donation found for the provided city and date");
        }     
        if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }
    
    @GetMapping("/city/{city}/type/{type}/page/{page}")
    public ResponseEntity<List<Donation>> findDonationByCityAndDonationType(@PathVariable String city,  @PathVariable DonationType type, @PathVariable int page, @RequestParam(required=false) boolean includeUser) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize);
        List<Donation> donations = DonationService.findDonationByCityAndDonationType(city, type, pageable);
        if (donations.isEmpty()) {
            throw new NotFoundException("No Donation found for the provided city, and Donation type");
        }
        if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }

    @GetMapping("/city/{city}/date/{date}/type/{type}/page/{page}")
    public ResponseEntity<List<Donation>> findDonationByCityAndDateAndDonationType(@PathVariable String city, @PathVariable Date date, @PathVariable DonationType type, @PathVariable int page, @RequestParam(required=false) boolean includeUser) throws NotFoundException {
        Pageable pageable = PageRequest.of(page, this.pageSize);
        List<Donation> donations = DonationService.findDonationByCityAndDateAndDonationType(city, date, type, pageable);
        if (donations.isEmpty()) {
            throw new NotFoundException("No Donation found for the provided city, date, and Donation type");
        }
        if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<Donation> updateDonationById(@PathVariable int id, @RequestBody Donation donation) throws NotFoundException, BadRequestException {
    	System.out.println(id+"......................................");
        Donation updatedDonation = DonationService.updateDonationById(id, donation);
        if (updatedDonation == null) {
            throw new BadRequestException("Failed to update the Donation");
        }
        updatedDonation.setUser(null);
        return new ResponseEntity<>(updatedDonation, HttpStatus.OK);
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteDonationById(@PathVariable int id) throws NotFoundException, BadRequestException {
        boolean isRemoved = DonationService.deleteDonationById(id);
        if (!isRemoved) {
            throw new BadRequestException("Failed to delete the Donation");
        }
        return new ResponseEntity<>("Donation deleted successfully", HttpStatus.OK);
    }
    
    @GetMapping("/user/{userId}/page/{page}")
    public ResponseEntity<List<Donation>> getDonationByUserId(@PathVariable int userId,@PathVariable int page,@RequestParam(required=false) boolean includeUser) throws NotFoundException, BadRequestException{
    	Pageable pageable = PageRequest.of(page, this.pageSize);
    	List<Donation> donations = DonationService.findDonationByUserId(userId, pageable);
        if (donations.isEmpty()) {
            throw new NotFoundException("No Donation donation found by the provided user");
        }
        if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }
    
    @GetMapping("/page/{page}")
    public ResponseEntity<List<Donation>> getAllDonation(@PathVariable int page,@RequestParam(required=false) boolean includeUser) throws NotFoundException, BadRequestException{
    	Pageable pageable = PageRequest.of(page, this.pageSize);
    	List<Donation> donations = DonationService.findAllDonation(pageable);
        if (donations.isEmpty()) {
            throw new NotFoundException("No Donation donation found by the provided user");
        }
        if(!includeUser) {
        	donations.forEach(Donation -> {
                Donation.setUser(null);
            });
        }
        return new ResponseEntity<>(donations, HttpStatus.OK);
    }
}
