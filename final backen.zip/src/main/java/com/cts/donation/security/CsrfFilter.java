package com.cts.donation.security;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class CsrfFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        // Log the HTTP method for debugging
        String method = httpRequest.getMethod();
        System.out.println("HTTP Method: " + method);

        // Check if the request method requires a CSRF token
        if ("POST".equalsIgnoreCase(method) ||
                "PUT".equalsIgnoreCase(method) ||
                "DELETE".equalsIgnoreCase(method) ||
                "PATCH".equalsIgnoreCase(method) ||
                "GET".equalsIgnoreCase(method)) {
            // Retrieve the CSRF token from the request attributes
            CsrfToken csrfToken = (CsrfToken) httpRequest.getAttribute(CsrfToken.class.getName());
            if (csrfToken != null) {
                System.out.println("new csrf token is: "+csrfToken.getToken());
                Cookie csrfCookie = new Cookie("csrf",csrfToken.getToken());
                csrfCookie.setPath("/");
                csrfCookie.setSecure(true);
                csrfCookie.setHttpOnly(false);


                httpResponse.addHeader("Set-Cookie",
                        String.format("%s=%s; Path=%s; Secure; SameSite=Strict",
                                csrfCookie.getName(),
                                csrfCookie.getValue(),
                                csrfCookie.getPath())
                );

            } else {
                System.out.println("CSRF Token not found in the request.");
            }
        }

//        chain.doFilter(request,response);
        chain.doFilter(httpRequest,httpResponse);
    }


}
