package com.cts.donation.security;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/v1/api")
public class CsrfController {

    /**
     * Endpoint to retrieve the CSRF token.
     *
     * @param request the HttpServletRequest object
     * @return the CSRF token wrapped in a ResponseEntity
     */
    @GetMapping("/csrf-token")
    public ResponseEntity<Map<String, String>> getCsrfToken(HttpServletRequest request, HttpServletResponse response) {
        // Retrieve the CSRF token from the request attributes
        CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());

        // Set the CSRF cookie
        Cookie csrfCookie = new Cookie("csrf", csrfToken.getToken());
        csrfCookie.setHttpOnly(false);
        csrfCookie.setSecure(true); // Ensure this is set to true in production with HTTPS
        csrfCookie.setPath("/");

        response.addHeader("Set-Cookie",
                String.format("%s=%s; Path=%s; Secure; SameSite=Strict",
                        csrfCookie.getName(),
                        csrfCookie.getValue(),
                        csrfCookie.getPath())
        );

        // Create a response body with the CSRF token
        Map<String, String> responseBody = new HashMap<>();
        responseBody.put("message", "CSRF token successfully generated");

        // Return the response entity with the CSRF token and HTTP status
        return new ResponseEntity<>(responseBody, HttpStatus.OK);
    }

}