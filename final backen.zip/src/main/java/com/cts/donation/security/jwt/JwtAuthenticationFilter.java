package com.cts.donation.security.jwt;

import com.cts.donation.entity.User;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.services.impl.UserServiceImpl;
import com.cts.donation.security.MyUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Autowired
    private MyUserDetailsService myUserDetailsService;

    @Autowired
    private UserServiceImpl userService;

    /**
     * Method to find user by refresh token.
     */
    public User userWithRefreshToken(String refreshToken) {
        try {
			return userService.findUserByRefreshToken(refreshToken);
		} catch (NotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return null;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String jwt = null;
        String refreshJwtToken = null;
        String username = null;

        // Get the cookies from the request
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("jwt")) {
                    jwt = cookie.getValue();
                    try {
                        username = jwtUtil.extractUsername(jwt);
                    } catch (Exception e) {
                        e.printStackTrace();  // Logging or better exception handling recommended
                    }
                    break;
                }
            }

            // If jwt is null, check for refresh token
            if (jwt == null) {
                for (Cookie cookie : cookies) {
                    if (cookie.getName().equals("refreshJwtToken")) {
                        refreshJwtToken = cookie.getValue();
                        try {
                            username = jwtUtil.extractUsernameFromRefreshToken(refreshJwtToken);
                        } catch (Exception e) {
                            e.printStackTrace();  // Logging or better exception handling recommended
                        }
                        break;
                    }
                }
            }
        }

        // Proceed if username is extracted and there is no active authentication
        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            UserDetails userDetails = myUserDetailsService.loadUserByUsername(username);

            if(jwt!=null){
                // Check if existing JWT is valid
                if(jwtUtil.validateToken(jwt, userDetails)){
                    authenticateUser(request, userDetails);
                }
            }else{
                User existingUserWithRefreshToken = userWithRefreshToken(refreshJwtToken);
                // Check if refresh token is valid and re-generate new tokens
                if(jwtUtil.validateRefreshToken(refreshJwtToken, userDetails) && existingUserWithRefreshToken != null){
                    // Authenticate user
                    authenticateUser(request, userDetails);

                    // Generate new tokens
                    String newAuthToken = jwtUtil.generateToken(userDetails);
                    String newRefreshToken = jwtUtil.generateRefreshToken(userDetails);

                    // Update user with new refresh token
                    userService.updateUserByRefreshToken(newRefreshToken, existingUserWithRefreshToken);

                    // Set new JWT and refresh token in cookies
                    setJwtCookie(response, "jwt", newAuthToken, 3600);  // 1 hour for jwt
                    setJwtCookie(response, "refreshJwtToken", newRefreshToken, 86400);  // 1 day for refresh token
                }
            }

        }

        filterChain.doFilter(request, response);
    }

    /**
     * Method to authenticate user based on user details.
     */
    private void authenticateUser(HttpServletRequest request, UserDetails userDetails) {
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
                new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
        usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
    }

    /**
     * Method to set JWT cookies in the response.
     */
    private void setJwtCookie(HttpServletResponse response, String name, String token, int maxAge) {
        Cookie cookie = new Cookie(name, token);
        cookie.setHttpOnly(true);
        cookie.setMaxAge(maxAge);
        cookie.setPath("/");
        cookie.setSecure(true);
        response.addCookie(cookie);
    }
}
