package com.cts.donation.repository;

import java.sql.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.Donation;


@Repository
public interface DonationRepository extends JpaRepository<Donation,Integer> {
	@Query("SELECT f FROM Donation f WHERE f.city = :city AND f.pickupDate >= CURRENT_DATE AND f.available = true")
	public Page<Donation> findByCity(@Param("city") String city, Pageable pageable);
	
	
	@Query("SELECT f FROM Donation f WHERE f.city = :city AND f.pickupDate = :date AND f.available = true")
	public Page<Donation> findByCityDate(@Param("city") String city,@Param("date") Date date, Pageable pagable);
	
	
	@Query("SELECT f FROM Donation f WHERE f.user.id = :userId ")
	public Page<Donation> findByUserId( @Param("userId") int userId, Pageable pageable);
	
	
	@Query("SELECT f FROM Donation f WHERE f.city = :city AND f.donationType = :type AND f.available = true")
	public Page<Donation> findByCityAndType(@Param("city") String city,  @Param("type") DonationType type, Pageable pagable);
	
	
	@Query("SELECT f FROM Donation f WHERE f.city = :city AND f.pickupDate = :date AND f.donationType = :type AND f.available = true")
	public Page<Donation> findByCityDateType(@Param("city") String city,@Param("date") Date date,@Param("type") DonationType type, Pageable pagable);
}
