package com.cts.donation.repository;

import java.sql.Date;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.DonationRequest;


@Repository
public interface DonationRequestRepository extends JpaRepository<DonationRequest,Integer> {
	@Query("SELECT f FROM DonationRequest f WHERE f.city = :city AND f.pickupDate >= CURRENT_DATE AND f.fullfilled = false")
	public Page<DonationRequest> findByCity(@Param("city") String city, Pageable pageable);

	public Page<DonationRequest> findByUserId(int userId,Pageable pageable);
	
	@Query("SELECT f FROM DonationRequest f WHERE f.city = :city AND f.pickupDate = :date AND f.fullfilled = false")
	public Page<DonationRequest> findByCityDate( @Param("city")String city, @Param("date") Date date,Pageable pageable);
	
	@Query("SELECT f FROM DonationRequest f WHERE f.city = :city AND f.donationType = :type AND f.fullfilled = false")
	public Page<DonationRequest> findByCityAndType(@Param("city") String city,@Param("type") DonationType type,Pageable pageable);
	
	@Query("SELECT f FROM DonationRequest f WHERE f.city = :city AND f.pickupDate = :date AND f.donationType = :type AND f.fullfilled = false")
	public Page<DonationRequest> findByCityDateType(@Param("city") String city,@Param("date") Date date,@Param("type") DonationType type,Pageable pageable);
}

