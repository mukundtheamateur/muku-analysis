package com.cts.donation.constant;

public enum DonationType {
	FURNITURE,
	CLOTHES,
	MATTRESS,
	PACKAGED_FOOD_ITEMS,
	MUSIC_INSTRUMENTS,
	AUTOMOBILES,
	VEG,
	NON_VEG,
	ANY
}
