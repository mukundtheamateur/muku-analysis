package com.cts.donation.constant;

public enum OrderStatus {
	PROCESSING,
	OUT_OF_DELIVERY,
	COMPLETED,
	CANCELED
	
}
