package com.cts.donation.constant;

public enum UserType {
	USER,
	VOLUNTEER,
	ADMIN
}
