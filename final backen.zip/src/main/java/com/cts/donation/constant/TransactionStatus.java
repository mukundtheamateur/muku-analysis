package com.cts.donation.constant;

public enum TransactionStatus {
	PENDING,
	SUCCESS,
	FAILED
}
