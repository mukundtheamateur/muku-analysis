package com.cts.donation.services.impl;

import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.Donation;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.DonationRepository;
import com.cts.donation.services.service.DonationService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DonationServiceImpl implements DonationService{

	@Autowired
	private DonationRepository repository;
	
	@Override
	public Donation addDonation(Donation donation) throws AlreadyExistException {
		log.info("Creating Donation");
		Donation newDonation = repository.save(donation);
		if(newDonation != null) {
			log.info("Donation created");
			return newDonation;
		}else {
			log.info("Donation creation failed");
			throw new AlreadyExistException("Donation creation failed");
		}
	}

	@Override
	public Donation findDonationById(int id) throws NotFoundException {
		log.info("Finding Donation with id="+id);
		Optional<Donation> donation = repository.findById(id);
		if(donation.isPresent()) {
			log.info("Founded Donation with id="+id);
			return donation.get();
		}else {
			log.info("No Donation found with id="+id);
			throw new NotFoundException("No Donation found with id="+id);
		}
	}

	@Override
	public List<Donation> findDonationByCity(String city, Pageable pagable) {
		log.info("Finding Donations in "+city);
		List<Donation> donations = repository.findByCity(city, pagable).getContent();
		log.info("Founded Donations in "+city);
		return donations;
	}

	@Override
	public List<Donation> findDonationByCityAndDate(String city, Date date, Pageable pagable) {
		log.info("Finding Donations in "+city +" on date "+date);
		List<Donation> donations = repository.findByCityDate(city, date, pagable).getContent();
		log.info("Founded Donations in "+city+" on date "+date);
		return donations;
	}

	@Override
	public List<Donation> findDonationByCityAndDateAndDonationType(String city, Date date, DonationType type, Pageable pagable) {
		log.info("Finding Donations in "+city +" on date "+date+" of type "+type.toString());
		List<Donation> donations = repository.findByCityDateType(city, date, type, pagable).getContent();
		log.info("Founded Donations in "+city +" on date "+date+" of type "+type.toString());
		return donations;
	}

	@Override
	public Donation updateDonationById(int id, Donation newDonation) throws NotFoundException {
		log.info("updating Donation with id="+id);
		Optional<Donation> donation = repository.findById(id);
		if(donation.isPresent()) {
			Donation oldDonation = donation.get();
			if(newDonation.getDonationName()!=null) {
				oldDonation.setDonationName(newDonation.getDonationName());
			}
			if(newDonation.getDonationType()!=null) {
				oldDonation.setDonationType(newDonation.getDonationType());
			}
			if(newDonation.getCity()!=null) {
				oldDonation.setCity(newDonation.getCity());
			}
			if(newDonation.getPickupDate()!=null) {
				oldDonation.setPickupDate(newDonation.getPickupDate());
			}
			if(newDonation.getPickupTime()!=null) {
				oldDonation.setPickupTime(newDonation.getPickupTime());
			}
			if(newDonation.getPickupAddress()!=null) {
				oldDonation.setPickupAddress(newDonation.getPickupAddress());
			}
			if(newDonation.getAvailable()!= null) {
				oldDonation.setAvailable(newDonation.getAvailable());
			}
			if(newDonation.getAmount()>=0) {
				oldDonation.setAmount(newDonation.getAmount());
			}
			repository.save(oldDonation);
			log.info("Donation updated with id="+id);
			return oldDonation;
		}else {
			log.info("No Donation found with id="+id);
			throw new NotFoundException("No Donation found with id="+id);
		}
	}

	@Override
	public boolean deleteDonationById(int id) throws NotFoundException {
		log.info("deleting Donation with id="+id);
		Optional<Donation> donation = repository.findById(id);
		if(donation.isPresent()) {
			repository.deleteById(id);
			log.info("Donation deleted with id="+id);
			return true;
		}else {
			log.info("No Donation found with id="+id);
			throw new NotFoundException("No Donation found with id="+id);
		}
	}

	@Override
	public List<Donation> findDonationByCityAndDonationType(String city, DonationType type, Pageable pagable) throws NotFoundException {
		log.info("Finding Donations in "+city +" of type "+type.toString());
		List<Donation> donations = repository.findByCityAndType(city,  type, pagable).getContent();
		log.info("Founded Donations in "+city +" of type "+type.toString());
		return donations;
	}

	@Override
	public List<Donation> findDonationByUserId(int userId, Pageable pageable) throws NotFoundException {
		log.info("Finding Donations posted by user "+userId);
		List<Donation> donations = repository.findByUserId(userId,pageable).getContent();
		log.info("Founded Donations posted by user "+userId);
		return donations;
	}

	@Override
	public List<Donation> findAllDonation(Pageable pageable) throws NotFoundException {
		log.info("Finding Donations posted by user ");
		List<Donation> donations = repository.findAll(pageable).getContent();
		log.info("Founded Donations posted by user ");
		return donations;
	}
}
