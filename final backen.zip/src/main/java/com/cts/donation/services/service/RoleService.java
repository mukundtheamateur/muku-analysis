package com.cts.donation.services.service;

import com.cts.donation.entity.Role;

public interface RoleService {
	public Role findDefaultRole();
}
