package com.cts.donation.services.service;

import java.util.List;

import com.cts.donation.entity.User;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;


public interface UserService {
	
	public User addUser(User user) throws AlreadyExistException;
	
	public User findUserById(int userId) throws NotFoundException;
	
	public User findUserByEmail(String email) throws NotFoundException;
	
	public List<User> findUserByRole(String role) throws NotFoundException;
	
	public User findUserByRefreshToken(String refreshToken) throws NotFoundException;
	
	public User updateUserById(int userId,User user) throws NotFoundException;
	public User updateUserByRefreshToken(String refreshToken,User user);
	
	public boolean deleteUserById(int userId) throws NotFoundException;
}
