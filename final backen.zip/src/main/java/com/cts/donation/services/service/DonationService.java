package com.cts.donation.services.service;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.Donation;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;

public interface DonationService {
	public Donation addDonation(Donation donation) throws AlreadyExistException;
	
	public Donation findDonationById(int id) throws NotFoundException;
	
	public List<Donation> findDonationByCity(String city, Pageable pagable) throws NotFoundException;
	
	public List<Donation> findDonationByCityAndDate(String city,Date date, Pageable pagable) throws NotFoundException;
	
	public List<Donation> findDonationByCityAndDonationType(String city,DonationType type, Pageable pagable) throws NotFoundException;
	
	public List<Donation> findDonationByCityAndDateAndDonationType(String city,Date date,DonationType type, Pageable pagable) throws NotFoundException;
	
	public Donation updateDonationById(int id, Donation donation) throws NotFoundException;
	
	public List<Donation> findDonationByUserId(int userId,Pageable pageable) throws NotFoundException;
	
	public List<Donation> findAllDonation(Pageable pageable) throws NotFoundException;
	
	public boolean deleteDonationById(int id) throws NotFoundException; 
}
