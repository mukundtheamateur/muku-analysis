package com.cts.donation.services.service;

import java.sql.Date;
import java.util.List;

import org.springframework.data.domain.Pageable;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.DonationRequest;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;

public interface DonationRequestService {
	public DonationRequest addDonationRequest(DonationRequest donationRequest) throws AlreadyExistException;
	
	public DonationRequest findDonationRequestById(int id) throws NotFoundException;
	
	public List<DonationRequest> findDonationRequestByUserId(int userId, Pageable pageable) throws NotFoundException;
	
	public List<DonationRequest> findAllDonationRequest(Pageable pageable) throws NotFoundException;
	
	public List<DonationRequest> findDonationRequestByCity(String city,Pageable pageable) throws NotFoundException;
	
	public List<DonationRequest> findDonationRequestByCityAndDate(String city,Date date,Pageable pageable) throws NotFoundException;
	
	public List<DonationRequest> findDonationRequestByCityAndDonationType(String city,DonationType type,Pageable pageable) throws NotFoundException;
	
	public List<DonationRequest> findDonationRequestByCityAndDateAndDonationType(String city,Date date,DonationType type,Pageable pageable) throws NotFoundException;
	
	public DonationRequest updateDonationRequestById(int id, DonationRequest donationRequest) throws NotFoundException;
	
	public boolean deleteDonationRequestById(int id) throws NotFoundException;
}
