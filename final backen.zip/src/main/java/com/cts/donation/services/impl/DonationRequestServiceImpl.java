package com.cts.donation.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.cts.donation.constant.DonationType;
import com.cts.donation.entity.DonationRequest;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;
import com.cts.donation.repository.DonationRequestRepository;
import com.cts.donation.services.service.DonationRequestService;

import lombok.extern.slf4j.Slf4j;
import java.sql.Date;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
public class DonationRequestServiceImpl implements DonationRequestService {

	@Autowired
	private DonationRequestRepository repository;
	
	@Override
	public DonationRequest addDonationRequest(DonationRequest donationRequest) throws AlreadyExistException {
		log.info("adding Donation request");
		DonationRequest newDonationRequest = repository.save(donationRequest);
		if(newDonationRequest != null) {
			log.info("Donation request added");
			return newDonationRequest;
		}else {
			log.info("Donation request creation failed");
			throw new AlreadyExistException("Donation request creation failed");
		}
	}

	@Override
	public DonationRequest findDonationRequestById(int id) throws NotFoundException {
		log.info("Finding Donation request with id="+id);
		Optional<DonationRequest> donationRequest = repository.findById(id);
		if(donationRequest.isPresent()) {
			log.info("Founded Donation request with id="+id);
			return donationRequest.get();
		}else {
			log.info("No Donation request found with id="+id);
			throw new NotFoundException("No Donation request found with id="+id);
		}
	}

	@Override
	public List<DonationRequest> findDonationRequestByCity(String city,Pageable pageable) throws NotFoundException {
		log.info("Finding Donation requests in "+city);
		List<DonationRequest> donationRequests = repository.findByCity(city,pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found in "+city);
			throw new NotFoundException("No Donation requests found in "+city);
		}
		log.info("Founded Donation requests in "+city);
		return donationRequests;
	}

	@Override
	public List<DonationRequest> findDonationRequestByCityAndDate(String city, Date date,Pageable pageable) throws NotFoundException {
		log.info("Finding Donation requests in "+city +" on date "+date);
		List<DonationRequest> donationRequests = repository.findByCityDate(city, date, pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found in "+city+" on date "+date);
			throw new NotFoundException("No Donation requests found in "+city+" on date "+date);
		}
		log.info("Founded Donation requests in "+city+" on date "+date);
		return donationRequests;
	}
	
	@Override
	public List<DonationRequest> findDonationRequestByCityAndDonationType(String city, DonationType type, Pageable pageable)
			throws NotFoundException {
		log.info("Finding Donation requests in "+city +" of type "+type.toString());
		List<DonationRequest> donationRequests = repository.findByCityAndType(city, type,pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found in "+city +" of type "+type.toString());
			throw new NotFoundException("No Donation requests found in "+city +" of type "+type.toString());
		}
		log.info("Founded Donation requests in "+city +" of type "+type.toString());
		return donationRequests;
	}

	@Override
	public List<DonationRequest> findDonationRequestByCityAndDateAndDonationType(String city, Date date, DonationType type,Pageable pageable) throws NotFoundException {
		log.info("Finding Donation requests in "+city +" on date "+date+" of type "+type.toString());
		List<DonationRequest> donationRequests = repository.findByCityDateType(city, date, type,pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found in "+city +" on date "+date+" of type "+type.toString());
			throw new NotFoundException("No Donation requests found in "+city +" on date "+date+" of type "+type.toString());
		}
		log.info("Founded Donation requests in "+city +" on date "+date+" of type "+type.toString());
		return donationRequests;
	}

	@Override
	public DonationRequest updateDonationRequestById(int id, DonationRequest newDonationRequest) throws NotFoundException {
		log.info("updating Donation request with id="+id);
		Optional<DonationRequest> donationRequest = repository.findById(id);
		if(donationRequest.isPresent()) {
			DonationRequest oldDonationRequest = donationRequest.get();
			if(newDonationRequest.getDonationType()!=null) {
				oldDonationRequest.setDonationType(newDonationRequest.getDonationType());
			}
			if(newDonationRequest.getCity()!=null) {
				oldDonationRequest.setCity(newDonationRequest.getCity());
			}
			if(newDonationRequest.getPickupDate()!=null) {
				oldDonationRequest.setPickupDate(newDonationRequest.getPickupDate());
			}
			if(newDonationRequest.getPickupTime()!=null) {
				oldDonationRequest.setPickupTime(newDonationRequest.getPickupTime());
			}
			if(newDonationRequest.getAmount() >=0) {
				oldDonationRequest.setAmount(newDonationRequest.getAmount());
			}
			if(newDonationRequest.getPickupAddress() !=null) {
				oldDonationRequest.setPickupAddress(newDonationRequest.getPickupAddress());
			}
			if(newDonationRequest.getFullfilled() != null) {
				oldDonationRequest.setFullfilled(newDonationRequest.getFullfilled());
			}
			if(newDonationRequest.getMessage() != null) {
				oldDonationRequest.setMessage(newDonationRequest.getMessage());
			}
			repository.save(oldDonationRequest);
			log.info("Donation request updated with id="+id);
			return oldDonationRequest;
		}else {
			log.info("No Donation request found with id="+id);
			throw new NotFoundException("No Donation request found with id="+id);
		}
	}

	@Override
	public boolean deleteDonationRequestById(int id) throws NotFoundException {
		log.info("deleting Donation request with id="+id);
		Optional<DonationRequest> donationRequest = repository.findById(id);
		if(donationRequest.isPresent()) {
			repository.deleteById(id);
			log.info("Donation request deleted with id="+id);
			return true;
		}else {
			log.info("No Donation request found with id="+id);
			throw new NotFoundException("No Donation request found with id="+id);
		}
	}

	@Override
	public List<DonationRequest> findDonationRequestByUserId(int userId,Pageable pageable) throws NotFoundException {
		log.info("finding Donation request posted by user id "+userId);
		List<DonationRequest> donationRequests = repository.findByUserId(userId,pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found by user id "+userId);
			throw new NotFoundException("No Donation requests found by user id "+userId);
		}
		log.info("No Donation requests found by user id "+userId);
		return donationRequests;
		
	}

	@Override
	public List<DonationRequest> findAllDonationRequest(Pageable pageable) throws NotFoundException {
		log.info("finding Donation request posted");
		List<DonationRequest> donationRequests = repository.findAll(pageable).getContent();
		if(donationRequests.isEmpty()){
			log.info("No Donation requests found ");
			throw new NotFoundException("No Donation requests found by ");
		}
		log.info("No Donation requests found ");
		return donationRequests;
	}

	
}
