package com.cts.donation.services.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.domain.Pageable;

import com.cts.donation.entity.Transaction;
import com.cts.donation.exception.AlreadyExistException;
import com.cts.donation.exception.NotFoundException;

public interface TransactionService {
	public Transaction addTransaction(Transaction transaction) throws AlreadyExistException;
	
	public Transaction findTransactionById(int id) throws NotFoundException;
	
	public List<Transaction> findTransactionByDonorId(int id,Pageable pageable) throws NotFoundException;
	
	public List<Transaction> findAllTransaction(Pageable pageable) throws NotFoundException;
	
	public List<Transaction> findTransactionByDate(Timestamp start, Timestamp end, Pageable pageable) throws NotFoundException;
	
	public List<Transaction> findTransactionByDonorIdAndDate(int id,Timestamp start, Timestamp end, Pageable pageable) throws NotFoundException;
	
	public Transaction updateTransaction(int id, Transaction transaction) throws NotFoundException;
	
	public boolean deleteTransactionById(int id) throws NotFoundException;
}
